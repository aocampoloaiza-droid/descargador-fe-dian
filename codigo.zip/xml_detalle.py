#!/usr/bin/env python3
"""
xml_detalle.py · Parseo detallado del XML UBL de la DIAN
────────────────────────────────────────────────────────────────────────────
De cada factura (dentro del AttachedDocument) extrae:
  · Encabezado enriquecido: concepto/notas, fecha de vencimiento, forma de pago,
    subtotal, descuentos, y los impuestos discriminados (IVA 5%, IVA 19%, INC,
    ICA, otros) y las retenciones.
  · Líneas de producto: descripción, código, cantidad, precio, total y el
    impuesto de CADA producto (tipo, tarifa %, base, valor).

`parse_zip(zip_bytes)` abre el ZIP del portal (que trae el/los XML) y parsea.
`parse(xml_bytes)` parsea un XML suelto. Devuelve un dict, o None si no aplica
(p.ej. nómina, que tiene otro esquema).
"""
import io
import zipfile
from xml.etree import ElementTree as ET

ESQUEMA = {"01": "IVA", "02": "IC", "03": "ICA", "04": "INC", "05": "ReteIVA",
           "06": "ReteFuente", "07": "ReteICA", "08": "ReteCREE",
           "20": "FtoHorticultura", "21": "Timbre", "22": "Bolsas",
           "23": "INCarbono", "24": "INCombustibles", "25": "Sobretasa",
           "34": "IBUA", "35": "ICUI", "36": "IES"}
FORMA_PAGO = {"1": "Contado", "2": "Crédito"}


def _loc(e):
    return e.tag.split("}")[-1]


def _num(s):
    if s is None or s == "":
        return None
    try:
        return round(float(str(s).replace(",", "")), 2)
    except ValueError:
        return None


def _first(el, *locs):
    for c in el.iter():
        if _loc(c) in locs and (c.text or "").strip():
            return c.text.strip()
    return ""


def _unwrap(root):
    """Si es un AttachedDocument, devuelve la factura embebida."""
    if _loc(root) != "AttachedDocument":
        return root
    for d in root.iter():
        if _loc(d) == "Description" and d.text and d.text.lstrip().startswith("<"):
            try:
                return ET.fromstring(d.text.strip().encode("utf-8"))
            except ET.ParseError:
                continue
    return root


def _esquema(sub_el):
    """(nombre, id) del esquema de impuesto dentro de un TaxSubtotal."""
    for ts in sub_el.iter():
        if _loc(ts) == "TaxScheme":
            name = sid = ""
            for c in ts:
                if _loc(c) == "Name":
                    name = (c.text or "").strip()
                elif _loc(c) == "ID":
                    sid = (c.text or "").strip()
            return name or ESQUEMA.get(sid, sid), sid
    return "", ""


def parse(xml_bytes):
    try:
        inv = _unwrap(ET.fromstring(xml_bytes))
    except ET.ParseError:
        return None
    tag = _loc(inv)
    if "Nomina" in tag:               # NominaIndividual / NominaIndividualDeAjuste
        return parse_nomina(inv)
    if tag not in ("Invoice", "CreditNote", "DebitNote"):
        return None  # otro esquema: sin detalle

    # Concepto: notas a nivel documento (omitiendo el texto técnico de la DIAN)
    notas = []
    for c in inv:
        if _loc(c) == "Note":
            t = "".join(c.itertext()).strip()
            if not t or t.startswith("NumFac:") or "ejemplar que reciba la DIAN" in t:
                continue
            notas.append(t)
    concepto = " | ".join(notas)[:600]

    # Vencimiento / forma de pago
    venc = forma = ""
    for pm in inv.iter():
        if _loc(pm) == "PaymentMeans":
            for c in pm:
                if _loc(c) == "PaymentDueDate":
                    venc = (c.text or "").strip()
                elif _loc(c) == "ID":
                    forma = FORMA_PAGO.get((c.text or "").strip(), (c.text or "").strip())
            if venc or forma:
                break

    # Totales
    sub = descu = total = None
    for lm in inv.iter():
        if _loc(lm) in ("LegalMonetaryTotal", "RequestedMonetaryTotal"):
            for c in lm:
                l = _loc(c)
                if l == "LineExtensionAmount":
                    sub = _num(c.text)
                elif l == "AllowanceTotalAmount":
                    descu = _num(c.text)
                elif l == "PayableAmount":
                    total = _num(c.text)
            break

    # Impuestos discriminados (TaxTotal a nivel documento)
    imp = {"IVA 5%": 0.0, "IVA 19%": 0.0, "IVA otro": 0.0, "INC": 0.0, "ICA": 0.0,
           "Otros imp.": 0.0}
    reten = 0.0
    for tt in inv:
        if _loc(tt) == "TaxTotal":
            for sub_el in tt.iter():
                if _loc(sub_el) != "TaxSubtotal":
                    continue
                nombre, sid = _esquema(sub_el)
                monto = _num(_first(sub_el, "TaxAmount")) or 0.0
                pct = _first(sub_el, "Percent")
                n = (nombre or "").upper()
                if "IVA" in n or sid == "01":
                    if pct.startswith("5"):
                        imp["IVA 5%"] += monto
                    elif pct.startswith("19"):
                        imp["IVA 19%"] += monto
                    else:
                        imp["IVA otro"] += monto
                elif "INC" in n or sid == "04":
                    imp["INC"] += monto
                elif "ICA" in n or sid == "03":
                    imp["ICA"] += monto
                else:
                    imp["Otros imp."] += monto
        elif _loc(tt) == "WithholdingTaxTotal":
            reten += _num(_first(tt, "TaxAmount")) or 0.0

    # Líneas de producto
    lineas = []
    for ln in inv.iter():
        if _loc(ln) not in ("InvoiceLine", "CreditNoteLine", "DebitNoteLine"):
            continue
        num = codigo = unidad = ""
        cant = precio = totln = None
        for c in ln:
            l = _loc(c)
            if l == "ID" and not num:
                num = (c.text or "").strip()
            elif l in ("InvoicedQuantity", "CreditedQuantity", "DebitedQuantity"):
                cant = _num(c.text)
                unidad = c.attrib.get("unitCode", "")
            elif l == "LineExtensionAmount":
                totln = _num(c.text)
        desc = _first(ln, "Description")
        for it in ln.iter():
            if _loc(it) == "SellersItemIdentification":
                codigo = _first(it, "ID")
                break
        if not codigo:
            for it in ln.iter():
                if _loc(it) == "StandardItemIdentification":
                    codigo = _first(it, "ID")
                    break
        for pr in ln.iter():
            if _loc(pr) == "Price":
                precio = _num(_first(pr, "PriceAmount"))
                break
        imp_nom = ""
        tarifa = base = valor = None
        for st in ln.iter():
            if _loc(st) == "TaxSubtotal":
                nombre, sid = _esquema(st)
                imp_nom = nombre or ESQUEMA.get(sid, "")
                tarifa = _num(_first(st, "Percent"))
                base = _num(_first(st, "TaxableAmount"))
                valor = _num(_first(st, "TaxAmount"))
                break
        if not imp_nom:
            imp_nom, tarifa = "Excluido/Exento", 0
        lineas.append({"num": num, "codigo": codigo, "desc": desc, "cant": cant,
                       "unidad": unidad, "precio": precio, "total": totln,
                       "impuesto": imp_nom, "tarifa": tarifa, "base": base, "valor": valor})

    return {"concepto": concepto, "vencimiento": venc, "forma": forma,
            "subtotal": sub, "descuentos": descu, "total": total,
            "reten": round(reten, 2) or None,
            "IVA 5%": round(imp["IVA 5%"], 2), "IVA 19%": round(imp["IVA 19%"], 2),
            "IVA otro": round(imp["IVA otro"], 2), "INC": round(imp["INC"], 2),
            "ICA": round(imp["ICA"], 2), "Otros imp.": round(imp["Otros imp."], 2),
            "lineas": lineas}


def parse_zip(zip_bytes):
    """Abre el ZIP del portal y parsea el primer XML de factura que encuentre."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile:
        return None
    for nombre in zf.namelist():
        if nombre.lower().endswith(".xml"):
            r = parse(zf.read(nombre))
            if r is not None:
                return r
    return None


# ── Nómina electrónica ──────────────────────────────────────────────────────
# Nombres legibles de los rubros (por tag del XML). Los que no estén acá se
# muestran con su nombre tal cual, o con "DescripcionConcepto" si lo traen.
RUBRO_LABEL = {
    "Basico": "Salario básico", "Transporte": "Auxilio de transporte",
    "HED": "Hora extra diurna", "HEN": "Hora extra nocturna", "HRN": "Recargo nocturno",
    "HEDDF": "H. extra diurna dom/fest", "HRDDF": "Recargo diurno dom/fest",
    "HENDF": "H. extra nocturna dom/fest", "HRNDF": "Recargo nocturno dom/fest",
    "Vacaciones": "Vacaciones", "VacacionesComunes": "Vacaciones",
    "VacacionesCompensadas": "Vacaciones compensadas", "Primas": "Prima",
    "Cesantias": "Cesantías", "Incapacidad": "Incapacidad", "Licencia": "Licencia",
    "LicenciaMP": "Licencia maternidad/paternidad", "LicenciaR": "Licencia remunerada",
    "LicenciaNR": "Licencia no remunerada", "Bonificacion": "Bonificación",
    "Auxilio": "Auxilio", "HuelgaLegal": "Huelga legal", "Compensacion": "Compensación",
    "BonoEPCTV": "Bono EPCTV", "Comision": "Comisión", "PagoTercero": "Pago de tercero",
    "Anticipo": "Anticipo", "Salud": "Salud", "FondoPension": "Fondo de pensión",
    "FondoSP": "Fondo solidaridad pensional", "Sindicato": "Sindicato",
    "Sancion": "Sanción", "Libranza": "Libranza", "PagoTercero": "Pago a tercero",
    "RetencionFuente": "Retención en la fuente", "Deuda": "Deuda",
    "OtraDeduccion": "Otra deducción", "Dependiente": "Dependientes",
    "AFC": "AFC", "Cooperativa": "Cooperativa", "PensionVoluntaria": "Pensión voluntaria",
    "EmbargoFiscal": "Embargo fiscal", "PlanComplementario": "Plan complementario",
}
# Atributos numéricos que NO son montos (cantidades, porcentajes, días…).
_NO_MONTO = {"Cantidad", "Porcentaje", "Dias", "DiasTrabajados", "Tipo",
             "CodigoTrabajador", "DV", "TRM", "PeriodoNomina", "Consecutivo",
             "TiempoLaborado", "Numero"}


def _monto_rubro(el):
    """Monto de un rubro: suma de atributos-monto + texto numérico (ej. Anticipo)."""
    tot, hay = 0.0, False
    for k, v in el.attrib.items():
        if k in _NO_MONTO:
            continue
        n = _num(v)
        if n is not None:
            tot += n
            hay = True
    if el.text and el.text.strip():
        n = _num(el.text)
        if n is not None:
            tot += n
            hay = True
    return round(tot, 2) if hay else None


def _rubros(seccion, tipo):
    out = []
    if seccion is None:
        return out
    for el in seccion.iter():
        if el is seccion:
            continue
        monto = _monto_rubro(el)
        if not monto:
            continue
        concepto = el.attrib.get("DescripcionConcepto") or RUBRO_LABEL.get(_loc(el), _loc(el))
        out.append({"tipo": tipo, "concepto": concepto, "valor": monto})
    return out


def parse_nomina(root):
    def buscar(tag):
        for e in root.iter():
            if _loc(e) == tag:
                return e
        return None
    ns = buscar("NumeroSecuenciaXML")
    trab = buscar("Trabajador")
    info = buscar("InformacionGeneral")
    periodo = buscar("Periodo")
    emp = buscar("Empleador")
    nombre = ""
    if trab is not None:
        nombre = " ".join(x for x in (trab.attrib.get("PrimerNombre"), trab.attrib.get("OtrosNombres"),
                                      trab.attrib.get("PrimerApellido"), trab.attrib.get("SegundoApellido")) if x)
        nombre = " ".join(nombre.split())
    fecha = ""
    if info is not None:
        fecha = info.attrib.get("FechaGen", "")
    if not fecha and periodo is not None:
        fecha = periodo.attrib.get("FechaGen", "")
    return {
        "_nomina": True,
        "prefijo": ns.attrib.get("Prefijo", "") if ns is not None else "",
        "numero": ns.attrib.get("Numero", "") if ns is not None else "",
        "fecha": fecha,
        "periodo": (f"{periodo.attrib.get('FechaLiquidacionInicio','')} a {periodo.attrib.get('FechaLiquidacionFin','')}"
                    if periodo is not None else ""),
        "trabajador": nombre,
        "documento": trab.attrib.get("NumeroDocumento", "") if trab is not None else "",
        "empleador": emp.attrib.get("RazonSocial", "") if emp is not None else "",
        "dev_total": _num(_first(root, "DevengadosTotal")),
        "ded_total": _num(_first(root, "DeduccionesTotal")),
        "neto": _num(_first(root, "ComprobanteTotal")),
        "rubros": _rubros(buscar("Devengados"), "Devengado") + _rubros(buscar("Deducciones"), "Deducción"),
    }
