#!/usr/bin/env python3
"""
core.py · Motor de descarga/consolidación DIAN (compartido por la app web y CLI)
────────────────────────────────────────────────────────────────────────────
Expone `ejecutar(cfg, progreso)` que hace todo el trabajo y reporta avance
llamando a la función `progreso(evento)` (para la barra de progreso del HTML).

cfg (dict):
    token_url     : URL de AuthToken del correo
    cliente       : nombre del cliente/empresa (para organizar y titular)
    fecha_desde   : "AAAA-MM-DD"
    fecha_hasta   : "AAAA-MM-DD"
    bandejas      : ["recibidos", "enviados"]
    formatos      : subconjunto de ["pdf", "xml"]   (vacío = no bajar archivos)
    generar_excel : bool
    carpeta       : carpeta destino (absoluta)

evento (dict) que recibe `progreso`:
    {"tipo": "info"|"doc"|"error"|"fin", "msg": str, "i": int, "n": int}
────────────────────────────────────────────────────────────────────────────
"""
import re
import io
import json
import time
import base64
import zipfile
from pathlib import Path
from datetime import datetime, timezone, timedelta


def _fmt_dur(seg):
    """Segundos -> texto corto tipo '~45 s' o '~3 min'."""
    seg = int(max(0, seg))
    if seg < 60:
        return f"~{seg} s"
    return f"~{seg // 60} min" if seg % 60 < 30 else f"~{seg // 60 + 1} min"

BASE = "https://catalogo-vpfe.dian.gov.co"
FILTER_TYPE = {"recibidos": "3", "enviados": "2"}
PAGINA_URL = {"recibidos": "/Document/Received", "enviados": "/Document/Sent"}
BLOQUE = 150
BOGOTA = timezone(timedelta(hours=-5))

JS_ENUM = r"""
async (p) => {
  const rvt = document.querySelector('input[name="__RequestVerificationToken"]')?.value || "";
  const body = new URLSearchParams({draw:String(p.draw),start:"0",length:String(p.length),
    DocumentKey:"",SerieAndNumber:"",SenderCode:"",ReceiverCode:"",
    StartDate:p.start,EndDate:p.end,DocumentTypeId:"00",Status:"0",
    IsNextPage:p.isNext?"true":"false",FilterType:p.filterType,
    blockIndex:String(p.blockIndex),RadianStatus:"0",ContinuationToken:p.cont||"",
    __RequestVerificationToken:rvt});
  const r = await fetch("/Document/GetDocumentsPageToken",{method:"POST",
    headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest"},
    body:body.toString()});
  return await r.json();
}
"""
JS_TOKEN = "document.querySelector('input[name=\"cf-turnstile-response\"]')?.value || ''"
JS_DL = r"""
async (url) => {
  const r = await fetch(url, {method:"GET"});
  const b = new Uint8Array(await r.arrayBuffer());
  const isZip = b.length>2 && b[0]===80 && b[1]===75;                            // 'PK'
  const isPdf = b.length>4 && b[0]===37 && b[1]===80 && b[2]===68 && b[3]===70;   // '%PDF'
  let s=""; for(let i=0;i<b.length;i++) s+=String.fromCharCode(b[i]);
  return {ct:r.headers.get("content-type")||"", len:b.length, isZip, isPdf, b64:btoa(s)};
}
"""


# ── utilidades ─────────────────────────────────────────────────────────────
def net_date(val, con_hora=False):
    if not val:
        return ""
    m = re.search(r"/Date\((\-?\d+)", str(val))
    if not m:
        return str(val)
    dt = datetime.fromtimestamp(int(m.group(1)) / 1000, tz=timezone.utc).astimezone(BOGOTA)
    return dt.strftime("%Y-%m-%d %H:%M") if con_hora else dt.strftime("%Y-%m-%d")


def limpiar(s):
    s = re.sub(r'[<>:"/\\|?*\n\r\t]+', " ", str(s or "")).strip()
    return re.sub(r"\s+", " ", s)[:45]


def es_nomina(doc):
    return "nomin" in (doc.get("DocumentTypeName") or "").lower()


def wait_token(pg, secs):
    for _ in range(secs):
        t = pg.evaluate(JS_TOKEN)
        if t:
            return t
        pg.wait_for_timeout(1000)
    return ""


def enumerar(pg, bandeja, desde, hasta):
    pg.goto(BASE + PAGINA_URL[bandeja], wait_until="domcontentloaded", timeout=45000)
    pg.wait_for_timeout(2000)
    todos, cont, total = [], "", None
    for block in range(0, 10000):
        resp = pg.evaluate(JS_ENUM, {"draw": block + 1, "length": BLOQUE,
                                     "start": desde, "end": hasta,
                                     "filterType": FILTER_TYPE[bandeja],
                                     "blockIndex": block, "cont": cont, "isNext": block > 0})
        rows = resp.get("data") or resp.get("blockData") or []
        if total is None:
            total = resp.get("recordsTotal") or 0
        todos.extend(rows)
        cont = resp.get("continuationToken") or ""
        if not rows or len(todos) >= total or not cont:
            break
    return todos


def _sesion_caida(pg):
    """True si la DIAN nos sacó (quedamos en la pantalla de login)."""
    try:
        t = (pg.title() or "")
    except Exception:
        return False
    return ("Acceder" in t) or ("Inicio" not in t and "Consultar" not in t and "DIAN" in t)


def _reconectar(pg, token_url, progreso):
    """Vuelve a entrar con el MISMO token cuando la DIAN cierra la sesión."""
    progreso({"tipo": "info", "msg": "⚠ La DIAN cerró la sesión — reconectando con tu token…"})
    try:
        pg.goto(token_url, wait_until="domcontentloaded", timeout=60000)
        pg.wait_for_timeout(2500)
        ok = "Inicio" in (pg.title() or "")
        progreso({"tipo": "info", "msg": "✓ Sesión restablecida." if ok else
                  "No pude reconectar (¿token vencido?). Pide uno nuevo al correo."})
        return ok
    except Exception:
        return False


def token_fresco(pg, bandeja, progreso, token_url=None):
    for intento in range(3):
        pg.goto(BASE + PAGINA_URL[bandeja], wait_until="domcontentloaded", timeout=45000)
        # Si la DIAN nos sacó, reconectar con el mismo token y volver a la bandeja
        if token_url and _sesion_caida(pg):
            if _reconectar(pg, token_url, progreso):
                pg.goto(BASE + PAGINA_URL[bandeja], wait_until="domcontentloaded", timeout=45000)
        t = wait_token(pg, 20)
        if t:
            return t
    progreso({"tipo": "info", "msg": "El captcha pide un clic — marca la casilla en la ventana de Chrome (espero 3 min)."})
    return wait_token(pg, 180)


# Tipos que el portal descarga con el endpoint de "documento equivalente"
# (POS, transporte, etc.). Tomado del propio JS del portal DIAN.
EQUIVALENTE_TYPES = {"20", "35", "40", "55", "27", "50", "60", "94", "45",
                     "32", "25", "93", "07", "08"}
# El portal deshabilita la descarga de estos (no hay archivo que bajar).
SIN_DESCARGA_TYPES = {"12", "101"}


def _fecha_dian(val):
    """/Date(ms)/ -> 'dd-MM-yyyy' (como lo arma el portal)."""
    m = re.search(r"/Date\((\-?\d+)", str(val or ""))
    if not m:
        return ""
    dt = datetime.fromtimestamp(int(m.group(1)) / 1000, tz=timezone.utc).astimezone(BOGOTA)
    return dt.strftime("%d-%m-%Y")


def descarga_deshabilitada(doc):
    """El portal no permite descargar estos documentos (botón deshabilitado)."""
    return (doc.get("Status") == 2 or
            str(doc.get("DocumentTypeId") or "") in SIN_DESCARGA_TYPES)


def url_descarga(doc, captcha):
    """Cada tipo de documento se baja por un endpoint distinto (igual que el portal)."""
    tid = doc["Id"]
    cap = captcha.replace("+", "%2B")
    t = str(doc.get("DocumentTypeId") or "")
    if t in ("102", "103") or es_nomina(doc):          # nómina individual / ajuste
        tok = doc.get("TokenConsulta") or ""
        return f"/Document/GetFilesIndividualPayroll?trackId={tid}&token={tok}&captcha={cap}"
    if t in ("05", "95"):                              # documento soporte → PDF directo
        return f"/Document/GetFilePdf?cune={tid}&captcha={cap}"
    if t == "96":                                      # eventos
        f = _fecha_dian(doc.get("EmissionDate"))
        return f"/Document/DownloadZipFilesEventos?trackId={tid}&code={f}&fecha={f}&captcha={cap}"
    if t in EQUIVALENTE_TYPES:                         # POS, transporte, etc.
        fe = _fecha_dian(doc.get("EmissionDate"))
        fg = _fecha_dian(doc.get("GenerationDate"))
        return (f"/Document/DownloadZipFilesEquivalente?trackId={tid}&documentTypeId={t}"
                f"&FechaValidacionDIAN={fe}&FechaGeneracionDIAN={fg}&captcha={cap}")
    return f"/Document/DownloadZipFiles?trackId={tid}&captcha={cap}"


def guardar(zip_bytes, doc, bandeja, carpeta_base, formatos):
    fecha = net_date(doc.get("EmissionDate")) or "sin-fecha"
    anio, mes = (fecha.split("-") + ["", ""])[:2] if "-" in fecha else ("otros", "")
    carpeta = (Path(carpeta_base) / ("Compras" if bandeja == "recibidos" else "Ventas")
               / anio / mes)
    carpeta.mkdir(parents=True, exist_ok=True)
    serie = limpiar(doc.get("SerieAndNumber") or doc.get("Number"))
    quien = limpiar(doc.get("SenderName") if bandeja == "recibidos" else doc.get("ReceiverName"))
    base = f"{fecha}_{serie}_{quien}".strip("_")
    guardados = []
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile:
        return []
    for nombre in zf.namelist():
        ext = nombre.rsplit(".", 1)[-1].lower()
        if ext not in formatos:
            continue
        destino = carpeta / f"{base}.{ext}"
        n = 1
        while destino.exists():
            destino = carpeta / f"{base}_{n}.{ext}"
            n += 1
        destino.write_bytes(zf.read(nombre))
        guardados.append(destino.name)
    return guardados


def guardar_pdf(pdf_bytes, doc, bandeja, carpeta_base, formatos):
    """Algunos documentos (p. ej. documento soporte) la DIAN los entrega como
    PDF suelto, no como ZIP."""
    if "pdf" not in formatos:
        return []
    fecha = net_date(doc.get("EmissionDate")) or "sin-fecha"
    anio, mes = (fecha.split("-") + ["", ""])[:2] if "-" in fecha else ("otros", "")
    carpeta = (Path(carpeta_base) / ("Compras" if bandeja == "recibidos" else "Ventas")
               / anio / mes)
    carpeta.mkdir(parents=True, exist_ok=True)
    serie = limpiar(doc.get("SerieAndNumber") or doc.get("Number"))
    quien = limpiar(doc.get("SenderName") if bandeja == "recibidos" else doc.get("ReceiverName"))
    base = f"{fecha}_{serie}_{quien}".strip("_")
    destino = carpeta / f"{base}.pdf"
    n = 1
    while destino.exists():
        destino = carpeta / f"{base}_{n}.pdf"
        n += 1
    destino.write_bytes(pdf_bytes)
    return [destino.name]


# ── Excel (2 hojas: Resumen + Detalle productos) ────────────────────────────
import xml_detalle

RESUMEN_COLS = ["Bandeja", "Tipo", "Estado", "CUFE/CUDE", "Prefijo", "Número", "Nº factura",
                "Fecha emisión", "Vencimiento", "Forma pago", "NIT Emisor", "Emisor",
                "NIT Receptor", "Receptor", "Concepto", "Subtotal", "Descuentos",
                "IVA 5%", "IVA 19%", "IVA otro", "INC", "ICA", "Retenciones",
                "Total", "Archivos"]
RESUMEN_NUM = {"Subtotal", "Descuentos", "IVA 5%", "IVA 19%", "IVA otro", "INC",
               "ICA", "Retenciones", "Total"}
DETALLE_COLS = ["Prefijo", "Número", "Nº factura", "CUFE/CUDE", "Fecha emisión",
                "Vencimiento", "Emisor", "# Línea", "Código", "Descripción",
                "Cantidad", "Unidad", "Precio unit.", "Total línea",
                "Impuesto", "Tarifa %", "Base gravable", "Valor impuesto"]
DETALLE_NUM = {"Cantidad", "Precio unit.", "Total línea", "Tarifa %",
               "Base gravable", "Valor impuesto"}


def fila_resumen(doc, bandeja, parsed, archivos):
    """Una fila por documento (hoja Resumen). Enriquece con el XML si hay."""
    # Impuestos que sí trae la API (aprovechamos el IVA total, no solo por tarifa)
    _iva5 = doc.get("TaxAmountIva5Percent") or 0
    _iva19 = doc.get("TaxAmountIva19Percent") or 0
    _ivatot = doc.get("TaxAmountIva") or 0
    _ivaotro = _ivatot - _iva5 - _iva19
    f = {"Bandeja": "Compra" if bandeja == "recibidos" else "Venta",
         "Tipo": doc.get("DocumentTypeName"), "Estado": doc.get("StatusName"),
         "CUFE/CUDE": doc.get("Id"), "Prefijo": doc.get("Serie"),
         "Número": doc.get("Number"),
         "Nº factura": doc.get("SerieAndNumber") or doc.get("Number"),
         "Fecha emisión": net_date(doc.get("EmissionDate")),
         "Vencimiento": "", "Forma pago": "",
         "NIT Emisor": doc.get("SenderCode"), "Emisor": doc.get("SenderName"),
         "NIT Receptor": doc.get("ReceiverCode"), "Receptor": doc.get("ReceiverName"),
         "Concepto": "", "Subtotal": doc.get("Amount") or None, "Descuentos": None,
         "IVA 5%": _iva5 or None, "IVA 19%": _iva19 or None,
         "IVA otro": (_ivaotro if _ivaotro > 0 else None),
         "INC": None, "ICA": doc.get("TaxAmountIca") or None,
         "Otros imp.": doc.get("TaxAmountIpc") or None, "Retenciones": None,
         "Devengado": None, "Deducción": None,
         "Total": doc.get("TotalAmount") or None, "Archivos": ", ".join(archivos)}
    if parsed and parsed.get("_nomina"):
        f.update({"Total": parsed["neto"] or f["Total"],
                  "Emisor": parsed["empleador"] or f["Emisor"],
                  "Receptor": parsed["trabajador"] or f["Receptor"],
                  "NIT Receptor": parsed["documento"] or f["NIT Receptor"],
                  "Devengado": parsed["dev_total"], "Deducción": parsed["ded_total"]})
    elif parsed:
        f.update({"Vencimiento": parsed["vencimiento"], "Forma pago": parsed["forma"],
                  "Concepto": parsed["concepto"], "Subtotal": parsed["subtotal"],
                  "Descuentos": parsed["descuentos"] or None,
                  "IVA 5%": parsed["IVA 5%"] or None, "IVA 19%": parsed["IVA 19%"] or None,
                  "IVA otro": parsed["IVA otro"] or None, "INC": parsed["INC"] or None,
                  "ICA": parsed["ICA"] or None, "Otros imp.": parsed.get("Otros imp.") or None,
                  "Retenciones": parsed["reten"],
                  "Total": parsed["total"]})
    return f


def filas_detalle(doc, parsed):
    """Filas por producto (hoja Detalle). El impuesto va discriminado por tarifa
    (tipo + tarifa % + valor) en cada línea."""
    if not parsed or not parsed.get("lineas"):
        return []
    prefijo = doc.get("Serie")
    numero = doc.get("Number")
    nfact = doc.get("SerieAndNumber") or numero
    fecha = net_date(doc.get("EmissionDate"))
    venc = parsed.get("vencimiento", "")
    emisor = doc.get("SenderName")
    cufe = doc.get("Id")
    out = []
    for L in parsed["lineas"]:
        out.append({"Prefijo": prefijo, "Número": numero, "Nº factura": nfact,
                    "CUFE/CUDE": cufe, "Fecha emisión": fecha, "Vencimiento": venc,
                    "Emisor": emisor, "# Línea": L["num"], "Código": L["codigo"],
                    "Descripción": L["desc"], "Cantidad": L["cant"], "Unidad": L["unidad"],
                    "Precio unit.": L["precio"], "Total línea": L["total"],
                    "Impuesto": L["impuesto"], "Tarifa %": L["tarifa"],
                    "Base gravable": L["base"], "Valor impuesto": L["valor"]})
    return out


def filas_detalle_nomina(doc, parsed):
    """Filas por rubro de nómina (hoja Detalle nómina): devengados y deducciones."""
    if not parsed or not parsed.get("_nomina"):
        return []
    out = []
    for r in parsed.get("rubros", []):
        out.append({"pref": parsed["prefijo"], "num": parsed["numero"],
                    "fecha": net_date(doc.get("EmissionDate")) or parsed.get("fecha", ""),
                    "periodo": parsed.get("periodo", ""), "doc": parsed["documento"],
                    "trab": parsed["trabajador"], "tipo": r["tipo"],
                    "concepto": r["concepto"], "valor": r["valor"], "cufe": doc.get("Id")})
    return out


def _nom_row(f):
    """Fila de la hoja Nómina (una por trabajador/documento)."""
    return {"tipo": f.get("Tipo"), "pref": f.get("Prefijo"), "folio": f.get("Número"),
            "femis": f.get("Fecha emisión"), "doc": f.get("NIT Receptor"),
            "trab": f.get("Receptor"), "dev": f.get("Devengado"), "ded": f.get("Deducción"),
            "neto": f.get("Total"), "estado": f.get("Estado"), "cufe": f.get("CUFE/CUDE")}


# ── Formato liquidación (Ventas/Compras/Nómina/Doc.soporte) ─────────────────
# Paleta AOL + formato dinero (negativos en rojo entre paréntesis)
_NAVY = "154360"; _CEL = "AED6F1"; _ZEBRA = "F6F9FC"; _MUTED = "5F7180"; _RED = "B0402A"
_MONEY = '"$"#,##0;[Red]("$"#,##0)'
_MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
          "agosto", "septiembre", "octubre", "noviembre", "diciembre"]

DET_COLS = [{"h": "Tipo de documento", "k": "tipo", "w": 28}, {"h": "Naturaleza", "k": "nat", "w": 14},
            {"h": "Prefijo", "k": "pref", "w": 9}, {"h": "Folio", "k": "folio", "w": 12},
            {"h": "Nº factura", "k": "nfac", "w": 15}, {"h": "Fecha Emisión", "k": "femis", "w": 13},
            {"h": "Vencimiento", "k": "venc", "w": 13}, {"h": "Forma pago", "k": "forma", "w": 12},
            {"h": "NIT Emisor", "k": "nitE", "w": 13}, {"h": "Nombre Emisor", "k": "nomE", "w": 32},
            {"h": "NIT Receptor", "k": "nitR", "w": 13}, {"h": "Nombre Receptor", "k": "nomR", "w": 32},
            {"h": "Descuentos", "k": "desc", "w": 13, "n": 1},
            {"h": "IVA 5%", "k": "iva5", "w": 12, "n": 1}, {"h": "IVA 19%", "k": "iva19", "w": 12, "n": 1},
            {"h": "IVA otro", "k": "ivao", "w": 12, "n": 1}, {"h": "INC", "k": "inc", "w": 11, "n": 1},
            {"h": "ICA", "k": "ica", "w": 11, "n": 1}, {"h": "Otros imp.", "k": "otros", "w": 12, "n": 1},
            {"h": "Retenciones", "k": "reten", "w": 13, "n": 1},
            {"h": "Total Impuestos", "k": "imp", "w": 15, "n": 1},
            {"h": "Subtotal", "k": "sub", "w": 15, "n": 1}, {"h": "Total", "k": "total", "w": 15, "n": 1},
            {"h": "Estado", "k": "estado", "w": 20}, {"h": "CUFE/CUDE", "k": "cufe", "w": 46}]
NOM_COLS = [{"h": "Tipo de documento", "k": "tipo", "w": 26}, {"h": "Prefijo", "k": "pref", "w": 9},
            {"h": "Folio", "k": "folio", "w": 12}, {"h": "Fecha", "k": "femis", "w": 13},
            {"h": "Documento", "k": "doc", "w": 14}, {"h": "Trabajador", "k": "trab", "w": 34},
            {"h": "Devengado", "k": "dev", "w": 15, "n": 1}, {"h": "Deducción", "k": "ded", "w": 15, "n": 1},
            {"h": "Neto", "k": "neto", "w": 15, "n": 1}, {"h": "Estado", "k": "estado", "w": 20},
            {"h": "CUFE/CUDE", "k": "cufe", "w": 46}]
DET_NOM_COLS = [{"h": "Prefijo", "k": "pref", "w": 9}, {"h": "Número", "k": "num", "w": 12},
                {"h": "Fecha", "k": "fecha", "w": 13}, {"h": "Periodo", "k": "periodo", "w": 22},
                {"h": "Documento", "k": "doc", "w": 14}, {"h": "Trabajador", "k": "trab", "w": 34},
                {"h": "Tipo", "k": "tipo", "w": 12}, {"h": "Concepto", "k": "concepto", "w": 34},
                {"h": "Valor", "k": "valor", "w": 15, "n": 1}]


def _num0(x):
    return x if isinstance(x, (int, float)) else 0


def _es_nota(tipo):
    """True si es nota crédito o de ajuste (RESTAN). Las notas débito SUMAN."""
    t = (tipo or "").lower()
    if "nota" in t and ("debito" in t or "débito" in t):
        return False
    return "nota" in t and ("credito" in t or "crédito" in t or "ajuste" in t)


def _omitir(doc):
    """Documentos que NO van al informe: 'Application response' (eventos DIAN:
    acuses, aceptaciones, reclamos…). No son facturas."""
    t = (doc.get("DocumentTypeName") or "").lower()
    return "application response" in t or "applicationresponse" in t


def _categoria(f):
    t = (f.get("Tipo") or "").lower()
    if "nomin" in t or "nómin" in t:
        return "Nómina electrónica"
    if "soporte" in t:
        return "Documento soporte"
    return "Ventas" if f.get("Bandeja") == "Venta" else "Compras"


def _liq(f):
    """Calcula subtotal = total − impuestos y aplica el signo de la nota."""
    iva = _num0(f.get("IVA 5%")) + _num0(f.get("IVA 19%")) + _num0(f.get("IVA otro"))
    inc = _num0(f.get("INC"))
    impuestos = iva + inc + _num0(f.get("ICA")) + _num0(f.get("Otros imp."))
    total = _num0(f.get("Total"))
    sub = total - impuestos
    nota = _es_nota(f.get("Tipo"))
    s = -1 if nota else 1
    return {"nota": nota, "iva": iva * s, "inc": inc * s, "imp": impuestos * s,
            "total": total * s, "sub": sub * s}


def _det_row(f):
    L = _liq(f)
    s = -1 if L["nota"] else 1

    def sg(v):
        return (_num0(v) * s) or None

    return {"tipo": f.get("Tipo"), "nat": "Nota (−)" if L["nota"] else "Documento (+)",
            "pref": f.get("Prefijo"), "folio": f.get("Número"), "nfac": f.get("Nº factura"),
            "femis": f.get("Fecha emisión"), "venc": f.get("Vencimiento"),
            "forma": f.get("Forma pago"),
            "nitE": f.get("NIT Emisor"), "nomE": f.get("Emisor"),
            "nitR": f.get("NIT Receptor"), "nomR": f.get("Receptor"),
            "concepto": f.get("Concepto"), "desc": sg(f.get("Descuentos")),
            "iva5": sg(f.get("IVA 5%")), "iva19": sg(f.get("IVA 19%")), "ivao": sg(f.get("IVA otro")),
            "inc": L["inc"] or None, "ica": sg(f.get("ICA")), "otros": sg(f.get("Otros imp.")),
            "reten": sg(f.get("Retenciones")),
            "imp": L["imp"] or None, "sub": L["sub"] or None, "total": L["total"] or None,
            "estado": f.get("Estado"), "cufe": f.get("CUFE/CUDE"), "_nota": L["nota"]}


def _hoja_tabla(ws, titulo, subtit, cols, rows):
    """Hoja de detalle estilo AOL: título, subtítulo, encabezado, filas (zebra,
    notas en rojo) y fila de TOTALES."""
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    last = get_column_letter(len(cols))
    ws.merge_cells(f"A1:{last}1")
    c = ws.cell(1, 1, titulo); c.fill = PatternFill("solid", fgColor=_NAVY)
    c.font = Font(bold=True, color="FFFFFF", size=13)
    c.alignment = Alignment(vertical="center", indent=1); ws.row_dimensions[1].height = 26
    ws.merge_cells(f"A2:{last}2")
    ws.cell(2, 1, subtit).font = Font(color=_MUTED, italic=True, size=10)
    hr = 4
    for j, col in enumerate(cols, 1):
        cc = ws.cell(hr, j, col["h"]); cc.fill = PatternFill("solid", fgColor=_CEL)
        cc.font = Font(bold=True, color="11212E", size=10)
        cc.alignment = Alignment(horizontal="right" if col.get("n") else "left")
    r = hr
    for row in rows:
        r += 1
        nota = row.get("_nota")
        zebra = (r - hr) % 2 == 0 and not nota
        for j, col in enumerate(cols, 1):
            cc = ws.cell(r, j, row.get(col["k"]))
            cc.font = Font(size=10, color=(_RED if nota else "11212E"),
                           bold=(col["k"] == "nat" and nota))
            if col.get("n"):
                cc.number_format = _MONEY
            if zebra:
                cc.fill = PatternFill("solid", fgColor=_ZEBRA)
    r += 1
    ws.cell(r, 1, "TOTALES").font = Font(bold=True)
    for j, col in enumerate(cols, 1):
        if col.get("n") and r - 1 > hr:
            LT = get_column_letter(j)
            cc = ws.cell(r, j, f"=SUM({LT}{hr+1}:{LT}{r-1})")
            cc.number_format = _MONEY; cc.font = Font(bold=True)
    for j, col in enumerate(cols, 1):
        ws.column_dimensions[get_column_letter(j)].width = col["w"]
    ws.freeze_panes = f"A{hr+1}"
    if rows:
        ws.auto_filter.ref = f"A{hr}:{last}{r-1}"


def _hoja_resumen(ws, ventas, compras_res, nomina):
    """Hoja 'Resumen' tipo liquidación (Ventas / Compras+Soporte / Nómina)."""
    from openpyxl.styles import Font, PatternFill, Alignment
    hoy = datetime.now()
    for L, w in (("A", 34), ("B", 18), ("C", 18), ("D", 18)):
        ws.column_dimensions[L].width = w

    def barra(r, texto, fill):
        ws.merge_cells(f"A{r}:D{r}")
        c = ws.cell(r, 1, texto); c.fill = PatternFill("solid", fgColor=fill)
        c.font = Font(bold=True, color="FFFFFF", size=13 if fill == _NAVY else 11)
        c.alignment = Alignment(vertical="center", indent=1); ws.row_dimensions[r].height = 24

    def suma(lst, key, solo=None):
        t = 0
        for f in lst:
            L = _liq(f)
            if solo == "suma" and L["nota"]:
                continue
            if solo == "resta" and not L["nota"]:
                continue
            t += L[key]
        return t

    def fila(r, etiqueta, vals, rojo=False, neto=False):
        ec = ws.cell(r, 1, etiqueta)
        ec.font = Font(bold=neto, color=_RED if rojo else "11212E", size=11)
        if neto:
            ec.fill = PatternFill("solid", fgColor=_CEL)
        for j, v in enumerate(vals, 2):
            cc = ws.cell(r, j, v); cc.number_format = _MONEY
            cc.font = Font(bold=neto, color=_RED if rojo else "11212E", size=11)
            if neto:
                cc.fill = PatternFill("solid", fgColor=_CEL)

    def encabezado_cols(r):
        for j, txt in ((2, "Subtotal"), (3, "Impuestos"), (4, "Total")):
            cc = ws.cell(r, j, txt); cc.fill = PatternFill("solid", fgColor="E8F4FB")
            cc.font = Font(bold=True, color="11212E"); cc.alignment = Alignment(horizontal="right")

    barra(1, "LIQUIDACIÓN DE DOCUMENTOS ELECTRÓNICOS · DIAN", _NAVY)
    ws.row_dimensions[1].height = 30
    ws.cell(2, 1, "AOL Consultoría Contable, Tributaria y Financiera").font = Font(bold=True, color=_NAVY, size=12)
    ws.cell(3, 1, f"Manizales, Caldas — Colombia · Generado el {hoy.day:02d} de {_MESES[hoy.month-1]} de {hoy.year}").font = Font(italic=True, color=_MUTED, size=10)

    r = 5
    barra(r, f"VENTAS (EMITIDOS)  ·  {len(ventas)} documentos", "1D5A80"); r += 1
    encabezado_cols(r); r += 1
    fila(r, "Facturas (+)", [suma(ventas, "sub", "suma"), suma(ventas, "imp", "suma"), suma(ventas, "total", "suma")]); r += 1
    fila(r, "Notas crédito (−)", [suma(ventas, "sub", "resta"), suma(ventas, "imp", "resta"), suma(ventas, "total", "resta")], rojo=True); r += 1
    fila(r, "NETO VENTAS", [suma(ventas, "sub"), suma(ventas, "imp"), suma(ventas, "total")], neto=True); r += 2

    barra(r, f"COMPRAS (RECIBIDOS + SOPORTE)  ·  {len(compras_res)} documentos", "1D5A80"); r += 1
    encabezado_cols(r); r += 1
    fila(r, "Documentos (+)", [suma(compras_res, "sub", "suma"), suma(compras_res, "imp", "suma"), suma(compras_res, "total", "suma")]); r += 1
    fila(r, "Notas de ajuste (−)", [suma(compras_res, "sub", "resta"), suma(compras_res, "imp", "resta"), suma(compras_res, "total", "resta")], rojo=True); r += 1
    fila(r, "NETO COMPRAS", [suma(compras_res, "sub"), suma(compras_res, "imp"), suma(compras_res, "total")], neto=True); r += 2

    barra(r, f"NÓMINA ELECTRÓNICA  ·  {len(nomina)} documentos", "1D5A80"); r += 1
    cc = ws.cell(r, 4, "Total"); cc.fill = PatternFill("solid", fgColor="E8F4FB")
    cc.font = Font(bold=True, color="11212E"); cc.alignment = Alignment(horizontal="right"); r += 1
    fila(r, "Total nómina", [None, None, suma(nomina, "total")], neto=True)


def generar_excel(resumen, detalle, detalle_nomina, ruta):
    """Excel tipo liquidación: hoja Resumen + Ventas / Compras / Documento
    soporte / Nómina + Detalle productos + Detalle nómina."""
    from openpyxl import Workbook
    ventas = [f for f in resumen if _categoria(f) == "Ventas"]
    compras = [f for f in resumen if _categoria(f) == "Compras"]
    soporte = [f for f in resumen if _categoria(f) == "Documento soporte"]
    nomina = [f for f in resumen if _categoria(f) == "Nómina electrónica"]

    wb = Workbook()
    _hoja_resumen(wb.active, ventas, compras + soporte, nomina)
    wb.active.title = "Resumen"

    for titulo, hoja, datos in (
            ("VENTAS · Facturas emitidas por la empresa", "Ventas", ventas),
            ("COMPRAS · Facturas recibidas de terceros", "Compras", compras),
            ("DOCUMENTO SOPORTE", "Documento soporte", soporte)):
        if datos:
            _hoja_tabla(wb.create_sheet(hoja), titulo, f"{len(datos)} documentos",
                        DET_COLS, [_det_row(f) for f in datos])

    if nomina:
        _hoja_tabla(wb.create_sheet("Nómina electrónica"), "NÓMINA ELECTRÓNICA",
                    f"{len(nomina)} documentos", NOM_COLS, [_nom_row(f) for f in nomina])

    if detalle:
        cat_por_cufe = {f.get("CUFE/CUDE"): _categoria(f) for f in resumen}
        cols_p = ([{"h": "Categoría", "k": "Categoría", "w": 16}] +
                  [{"h": c, "k": c, "w": (46 if "CUFE" in c else 34 if c == "Descripción" else
                    13 if c in DETALLE_NUM else 14), "n": 1 if c in DETALLE_NUM else 0}
                   for c in DETALLE_COLS])
        filas_p = []
        for d in detalle:
            row = dict(d); row["Categoría"] = cat_por_cufe.get(d.get("CUFE/CUDE"), "")
            filas_p.append(row)
        _hoja_tabla(wb.create_sheet("Detalle productos"),
                    "DETALLE DE PRODUCTOS", f"{len(filas_p)} líneas", cols_p, filas_p)

    if detalle_nomina:
        _hoja_tabla(wb.create_sheet("Detalle nómina"), "DETALLE DE NÓMINA (rubros)",
                    f"{len(detalle_nomina)} rubros", DET_NOM_COLS, detalle_nomina)

    wb.save(ruta)


# ── orquestador ─────────────────────────────────────────────────────────────
def _lanzar_ctx(p, profile):
    """Abre el navegador: intenta el Chrome real del PC; si no hay, usa el
    Chromium propio de patchright (el que va empaquetado en el .exe).
    Prefiere el sandbox ACTIVADO (sin la advertencia --no-sandbox, más seguro);
    si por alguna razón no arranca así, cae a sin sandbox."""
    ultimo = None
    for sandbox in (True, False):
        for extra in ({"channel": "chrome"}, {"channel": "msedge"}, {}):
            try:
                return p.chromium.launch_persistent_context(
                    profile, headless=False, no_viewport=True,
                    chromium_sandbox=sandbox, **extra)
            except Exception as e:
                ultimo = e
    raise ultimo


def ejecutar(cfg, progreso):
    """Corre todo el proceso. `progreso(evento)` para reportar avance a la UI."""
    from patchright.sync_api import sync_playwright

    formatos = [f.lower() for f in cfg.get("formatos", []) if f.lower() in ("pdf", "xml")]
    bandejas = cfg.get("bandejas") or ["recibidos"]
    carpeta = Path(cfg["carpeta"])
    carpeta.mkdir(parents=True, exist_ok=True)
    # excel_completo: lee el XML de cada doc (para impuestos/concepto/vencimiento)
    # aunque NO se guarden los archivos. Es más lento pero da el Excel completo.
    excel_completo = bool(cfg.get("excel_completo"))
    bajar_archivos = bool(formatos) or excel_completo
    cliente = cfg.get("cliente") or "cliente"

    # registro de descargados (reanudable) por carpeta
    reg = carpeta / "_descargados.txt"
    hechos = set(reg.read_text(encoding="utf-8").split()) if reg.exists() else set()

    profile = str(Path(cfg.get("profile_dir", "chrome_profile")).resolve())

    # Acumulador persistente: el Excel refleja TODO lo descargado a esta carpeta,
    # de todas las corridas/rangos (no solo la corrida actual).
    datos_file = carpeta / "_datos.json"
    acc = {"resumen": {}, "detalle": {}, "detalle_nomina": {}}
    if datos_file.exists():
        try:
            acc = json.loads(datos_file.read_text(encoding="utf-8"))
        except Exception:
            acc = {}
    acc.setdefault("resumen", {})
    acc.setdefault("detalle", {})
    acc.setdefault("detalle_nomina", {})
    total_ok = 0

    def _guardar_fila(doc_id, resumen_row, detalle_list, det_nom_list, rico):
        # No degradar una fila ya detallada (del XML) con una versión pobre (API).
        prev = acc["resumen"].get(doc_id)
        if prev and not rico and prev.get("Concepto"):
            return
        acc["resumen"][doc_id] = resumen_row
        if detalle_list:
            acc["detalle"][doc_id] = detalle_list
        if det_nom_list:
            acc["detalle_nomina"][doc_id] = det_nom_list

    with sync_playwright() as p:
        progreso({"tipo": "info", "msg": "Abriendo el navegador (no cierres esa ventana)…"})
        ctx = _lanzar_ctx(p, profile)
        pg = ctx.pages[0] if ctx.pages else ctx.new_page()
        pg.goto(cfg["token_url"], wait_until="domcontentloaded", timeout=60000)
        pg.wait_for_timeout(2500)
        titulo = pg.title()
        if "Inicio" not in (titulo or ""):
            progreso({"tipo": "error", "msg": f"No autenticó (título: {titulo!r}). ¿El token expiró? Pide otro al correo."})
            ctx.close()
            progreso({"tipo": "fin", "msg": "Terminado con error de sesión.", "ok": 0})
            return
        progreso({"tipo": "info", "msg": f"Sesión iniciada para «{cliente}»."})

        reg_fh = reg.open("a", encoding="utf-8")
        dl_start = time.monotonic()   # cronómetro para el estimado de tiempo
        hechos_run = 0                # descargas exitosas en esta corrida

        def _bajar_doc(doc, bandeja):
            """Baja y procesa un documento. Si la DIAN cierra la sesión,
            reconecta con el mismo token y reintenta. True si quedó guardado."""
            for intento in (1, 2):
                cap = token_fresco(pg, bandeja, progreso, cfg["token_url"])
                if not cap:
                    continue
                try:
                    res = pg.evaluate(JS_DL, url_descarga(doc, cap))
                except Exception:
                    res = {}
                if res.get("isZip") or res.get("isPdf"):
                    datos = base64.b64decode(res["b64"])
                    if res.get("isZip"):
                        archivos = guardar(datos, doc, bandeja, carpeta, formatos)
                        try:
                            parsed = xml_detalle.parse_zip(datos)
                        except Exception:
                            parsed = None
                    else:                      # PDF suelto (p. ej. documento soporte)
                        archivos = guardar_pdf(datos, doc, bandeja, carpeta, formatos)
                        parsed = None
                    _guardar_fila(doc["Id"], fila_resumen(doc, bandeja, parsed, archivos),
                                  filas_detalle(doc, parsed), filas_detalle_nomina(doc, parsed),
                                  bool(parsed))
                    hechos.add(doc["Id"]); reg_fh.write(doc["Id"] + "\n"); reg_fh.flush()
                    return True
                # Falló: si nos sacaron de la DIAN, reconectar antes de reintentar
                if _sesion_caida(pg):
                    _reconectar(pg, cfg["token_url"], progreso)
            return False

        for bandeja in bandejas:
            progreso({"tipo": "info", "msg": f"Consultando {bandeja}…"})
            docs = enumerar(pg, bandeja, cfg["fecha_desde"], cfg["fecha_hasta"])
            docs = [d for d in docs if not _omitir(d)]   # sin 'Application response'
            progreso({"tipo": "info", "msg": f"{len(docs)} documentos en {bandeja}."})

            if not bajar_archivos:
                # solo Excel rápido: no se descargan archivos (solo hoja Resumen)
                for d in docs:
                    _guardar_fila(d["Id"], fila_resumen(d, bandeja, None, []), [], [], False)
                continue

            pend = [d for d in docs if d["Id"] not in hechos]
            n = len(pend)
            fallidos = []
            for i, doc in enumerate(pend, 1):
                etiqueta = f"{doc.get('SerieAndNumber')} · {limpiar(doc.get('SenderName'))}"
                if descarga_deshabilitada(doc):
                    progreso({"tipo": "info", "msg": f"↷ Sin descarga en el portal: {etiqueta}",
                              "i": i, "n": n})
                    continue
                if _bajar_doc(doc, bandeja):
                    total_ok += 1
                    hechos_run += 1
                    transcurrido = time.monotonic() - dl_start
                    eta = _fmt_dur((transcurrido / hechos_run) * (n - i))
                    progreso({"tipo": "doc", "msg": f"✓ {etiqueta}", "i": i, "n": n,
                              "eta_txt": f"{i} de {n} · faltan {eta}",
                              "transcurrido_txt": _fmt_dur(transcurrido)})
                else:
                    fallidos.append(doc)
                    progreso({"tipo": "error", "msg": f"Falló: {etiqueta}", "i": i, "n": n})

            # Segunda pasada: reintentar los que fallaron (reconectando primero)
            if fallidos:
                progreso({"tipo": "info",
                          "msg": f"↻ Reintentando {len(fallidos)} documento(s) que fallaron…"})
                _reconectar(pg, cfg["token_url"], progreso)
                quedan = 0
                for j, doc in enumerate(fallidos, 1):
                    etiqueta = f"{doc.get('SerieAndNumber')} · {limpiar(doc.get('SenderName'))}"
                    if _bajar_doc(doc, bandeja):
                        total_ok += 1
                        progreso({"tipo": "doc", "msg": f"✓ (reintento) {etiqueta}",
                                  "i": j, "n": len(fallidos)})
                    else:
                        quedan += 1
                        progreso({"tipo": "error", "msg": f"Falló otra vez: {etiqueta}",
                                  "i": j, "n": len(fallidos)})
                if quedan:
                    progreso({"tipo": "error", "msg": f"⚠ Quedaron {quedan} sin descargar. "
                              "Pide un token fresco y vuelve a correr: continúa donde iba."})
        reg_fh.close()
        ctx.close()

    # Persistir el acumulador para futuras corridas (Excel acumulativo)
    try:
        datos_file.write_text(json.dumps(acc, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

    ruta_excel = None
    if cfg.get("generar_excel") and acc["resumen"]:
        resumen = sorted(acc["resumen"].values(),
                         key=lambda f: (f.get("Fecha emisión") or "", f.get("Emisor") or ""))
        detalle = []
        detalle_nomina = []
        for r in resumen:
            cufe = r.get("CUFE/CUDE")
            detalle.extend(acc["detalle"].get(cufe, []))
            detalle_nomina.extend(acc.get("detalle_nomina", {}).get(cufe, []))
        ruta_excel = carpeta / f"Consolidado_{limpiar(cliente)}.xlsx"
        try:
            generar_excel(resumen, detalle, detalle_nomina, ruta_excel)
            hojas = "Resumen + detalle" if (detalle or detalle_nomina) else "Resumen"
            progreso({"tipo": "info",
                      "msg": f"Excel actualizado ({len(resumen)} docs · {hojas}): {ruta_excel.name}"})
        except PermissionError:
            ruta_excel = None
            progreso({"tipo": "error", "msg": "No pude guardar el Excel: ciérralo si lo tienes "
                      "abierto y vuelve a correr (los archivos ya quedaron bajados)."})

    progreso({"tipo": "fin", "msg": "¡Listo!", "ok": total_ok,
              "excel": str(ruta_excel) if ruta_excel else None,
              "carpeta": str(carpeta)})
