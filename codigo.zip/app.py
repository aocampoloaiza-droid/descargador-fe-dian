#!/usr/bin/env python3
"""
app.py · Interfaz local (HTML) del Descargador FE DIAN
────────────────────────────────────────────────────────────────────────────
Levanta un servidor local y abre una página en el navegador donde el usuario
pega su token, elige cliente / fechas / formatos / carpeta, y descarga con una
barra de progreso. Corre 100% en el PC de la persona (usa su Chrome real).

Se lanza con doble clic en «Descargador DIAN.bat».
────────────────────────────────────────────────────────────────────────────
"""
import os
import sys
import json
import threading
import webbrowser
from pathlib import Path
from datetime import date

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
import uvicorn

import core

try:
    import version as _ver
    APP_VERSION = getattr(_ver, "CODE_VERSION", "?")
except Exception:
    APP_VERSION = "?"

# Lo setea main_app.py con el resultado del chequeo de actualizaciones
UPDATE_INFO = {}

# Carpeta de datos: junto al script en dev; en %LOCALAPPDATA% cuando es .exe
# (el bundle de PyInstaller es temporal/solo-lectura, no sirve para guardar).
if getattr(sys, "frozen", False):
    APP_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "ProcesadorXML-FE"
else:
    APP_DIR = Path(__file__).parent
APP_DIR.mkdir(parents=True, exist_ok=True)
CLIENTES_FILE = APP_DIR / "clientes.json"
PROFILE_DIR = str(APP_DIR / "chrome_profile")
PUERTO = 8756

app = FastAPI()

# Estado del trabajo en curso (un solo trabajo a la vez; es de uso local)
JOB = {"running": False, "eventos": [], "fin": None}
LOCK = threading.Lock()


def progreso(ev):
    with LOCK:
        JOB["eventos"].append(ev)
        if ev.get("tipo") == "fin":
            JOB["fin"] = ev
            JOB["running"] = False


def cargar_clientes():
    if CLIENTES_FILE.exists():
        try:
            return json.loads(CLIENTES_FILE.read_text(encoding="utf-8")).get("clientes", [])
        except Exception:
            return []
    return []


def guardar_cliente(nombre, carpeta):
    clientes = cargar_clientes()
    nombre = (nombre or "").strip()
    if not nombre:
        return
    for c in clientes:
        if c.get("nombre", "").lower() == nombre.lower():
            c["carpeta"] = carpeta
            break
    else:
        clientes.append({"nombre": nombre, "carpeta": carpeta})
    CLIENTES_FILE.write_text(json.dumps({"clientes": clientes}, ensure_ascii=False, indent=2),
                             encoding="utf-8")


def correr_job(cfg):
    try:
        core.ejecutar(cfg, progreso)
    except Exception as e:
        progreso({"tipo": "error", "msg": f"Error inesperado: {e}"})
        progreso({"tipo": "fin", "msg": "Terminado con error.", "ok": 0})


@app.get("/", response_class=HTMLResponse)
def home():
    return HTML_PAGINA


@app.get("/clientes")
def clientes():
    return {"clientes": cargar_clientes()}


@app.get("/appinfo")
def appinfo():
    return {"version": APP_VERSION,
            "code_updated": bool(UPDATE_INFO.get("code_updated")),
            "runtime_update": bool(UPDATE_INFO.get("runtime_update")),
            "full_zip": UPDATE_INFO.get("full_zip", ""),
            "notas": UPDATE_INFO.get("notas", "")}


@app.post("/iniciar")
async def iniciar(req: Request):
    if JOB["running"]:
        return JSONResponse({"error": "Ya hay una descarga en curso."}, status_code=409)
    cfg = await req.json()
    # validación mínima
    if not cfg.get("token_url", "").startswith("http"):
        return JSONResponse({"error": "Pega la URL completa del token."}, status_code=400)
    if not cfg.get("carpeta"):
        return JSONResponse({"error": "Elige una carpeta destino."}, status_code=400)
    cfg["profile_dir"] = PROFILE_DIR
    guardar_cliente(cfg.get("cliente"), cfg.get("carpeta"))
    with LOCK:
        JOB["running"] = True
        JOB["eventos"] = []
        JOB["fin"] = None
    threading.Thread(target=correr_job, args=(cfg,), daemon=True).start()
    return {"ok": True}


@app.get("/estado")
def estado():
    with LOCK:
        return {"running": JOB["running"], "eventos": JOB["eventos"], "fin": JOB["fin"]}


WEBVIEW_WINDOW = None  # lo setea main_app.py cuando corre como ventana nativa


@app.get("/elegir-carpeta")
def elegir_carpeta():
    """Abre un diálogo nativo para escoger carpeta (pywebview o tkinter)."""
    # 1) Si corremos en ventana nativa, usar su diálogo (más confiable en el .exe)
    if WEBVIEW_WINDOW is not None:
        try:
            import webview
            res = WEBVIEW_WINDOW.create_file_dialog(webview.FOLDER_DIALOG)
            path = (res[0] if res else "") or ""
            return {"path": path}
        except Exception as e:
            return {"error": str(e)}
    # 2) Modo navegador/dev: tkinter
    resultado = {"path": ""}

    def _dialog():
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            resultado["path"] = filedialog.askdirectory(title="Elige la carpeta destino") or ""
            root.destroy()
        except Exception as e:
            resultado["error"] = str(e)

    t = threading.Thread(target=_dialog)
    t.start()
    t.join(timeout=120)
    return resultado


@app.get("/abrir-carpeta")
def abrir_carpeta(path: str = ""):
    try:
        import os
        if path and Path(path).exists():
            os.startfile(path)  # Windows
            return {"ok": True}
    except Exception as e:
        return {"error": str(e)}
    return {"error": "No se encontró la carpeta."}


# ── Página HTML (una sola, sin dependencias externas) ──────────────────────
_hoy = date.today().isoformat()
_primero = date.today().replace(day=1).isoformat()

# Conejito de AOL (SVG en línea, azul de la marca). Es el logo de la app.
BUNNY = (
    '<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-label="AOL">'
    '<g fill="#26324a">'
    '<ellipse cx="25" cy="21" rx="6.2" ry="15.5" transform="rotate(-14 25 21)"/>'
    '<ellipse cx="39" cy="21" rx="6.2" ry="15.5" transform="rotate(14 39 21)"/>'
    '</g>'
    '<g fill="#f3a6ad">'
    '<ellipse cx="25.5" cy="23" rx="2.6" ry="8.6" transform="rotate(-14 25.5 23)"/>'
    '<ellipse cx="38.5" cy="23" rx="2.6" ry="8.6" transform="rotate(14 38.5 23)"/>'
    '</g>'
    '<circle cx="32" cy="43" r="16" fill="#26324a"/>'
    '<circle cx="26.4" cy="41.5" r="2.2" fill="#fff"/>'
    '<circle cx="37.6" cy="41.5" r="2.2" fill="#fff"/>'
    '<circle cx="32" cy="47" r="1.9" fill="#f3a6ad"/>'
    '<path d="M32 48.8 v2.2" stroke="#0f1a2e" stroke-width="1.1" stroke-linecap="round"/>'
    '</svg>'
)
import base64 as _b64
_FAVICON = "data:image/svg+xml;base64," + _b64.b64encode(BUNNY.encode("utf-8")).decode()


def _logo_uri():
    """Data URI del logo AOL (logo.png) si está disponible; si no, vacío."""
    bases = []
    if getattr(sys, "frozen", False):
        bases.append(Path(sys._MEIPASS))            # dentro del .exe
    bases.append(Path(__file__).parent)             # junto al código
    for base in bases:
        f = base / "logo.png"
        if f.exists():
            return "data:image/png;base64," + _b64.b64encode(f.read_bytes()).decode()
    return ""


LOGO_URI = _logo_uri()
# Logo para el header/footer; si no hay logo.png, cae al conejito.
_LOGO_H = f'<img class="logo-h" src="{LOGO_URI}" alt="AOL Consultoría">' if LOGO_URI else BUNNY
_LOGO_F = f'<img class="logo-f" src="{LOGO_URI}" alt="AOL">' if LOGO_URI else BUNNY
_FAV = LOGO_URI or _FAVICON

HTML_PAGINA = """<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AOL Consultoría - Procesador Xml - Pdf y Excel</title>
<link rel="icon" href="__FAVICON__">
<style>
  :root { --azul:#1F4E78; --azul2:#3f5bd9; --ok:#1a7f37; --okbg:#e7f6ec; --err:#c1121f; --bg:#eef1f6; }
  * { box-sizing:border-box; }
  body { font-family:'Calibri Light','Calibri','Segoe UI',system-ui,sans-serif; margin:0;
    background:var(--bg); color:#1c2733;
    display:flex; flex-direction:column; align-items:center; min-height:100vh; }
  header { position:sticky; top:0; z-index:20; width:100%;
    background:linear-gradient(120deg,#1c2740 0%,#26324a 45%,#33507e 100%);
    color:#fff; padding:18px 24px; box-shadow:0 2px 10px rgba(15,25,45,.28); }
  header .hwrap { max-width:860px; margin:0 auto; display:flex; align-items:center; gap:16px; }
  .badge { flex:0 0 auto; border-radius:14px; background:#fff; padding:10px 16px;
    display:flex; align-items:center; justify-content:center; box-shadow:0 3px 10px rgba(0,0,0,.18); }
  .badge svg { width:44px; height:44px; }
  .badge .logo-h { height:34px; width:auto; display:block; }
  footer.brand .logo-f { height:26px; width:auto; display:block; margin:0 auto; opacity:.9; }
  header h1 { margin:0; font-size:22px; letter-spacing:.3px; }
  header .sub { opacity:.92; font-size:13px; margin-top:2px; }
  header .loc { opacity:.75; font-size:12px; margin-top:1px; }
  footer.brand { width:100%; max-width:860px; margin:8px auto 26px; padding:18px 22px; text-align:center; }
  footer.brand .mini { margin:0 auto 10px; display:flex; justify-content:center; }
  footer.brand .mini svg { width:34px; height:34px; }
  footer.brand .lema { font-style:italic; color:#3a4a63; font-size:14px; max-width:560px;
    margin:0 auto 12px; line-height:1.5; }
  footer.brand .cred { font-size:11.5px; color:#7a889b; line-height:1.6; }
  footer.brand a { color:#33507e; text-decoration:none; }
  .banner { width:100%; max-width:860px; margin:16px auto 0; padding:0 16px; }
  .banner .tok { background:var(--okbg); border:1px solid #a6dfba; color:#1a5b30;
    border-radius:10px; padding:11px 16px; font-size:14px; font-weight:500; }
  .wrap { width:100%; max-width:860px; margin:16px auto; padding:0 16px; }
  .card { background:#fff; border-radius:14px; padding:22px 24px; box-shadow:0 2px 10px rgba(30,50,90,.07); margin-bottom:16px; }
  .card h2 { margin:0 0 4px; font-size:17px; color:#26324a; }
  label { display:block; font-weight:600; margin:14px 0 6px; font-size:14px; }
  input[type=text], input[type=date], textarea, select {
    width:100%; padding:11px 12px; border:1px solid #cdd5df; border-radius:9px; font-size:14px; font-family:inherit; }
  input:focus, textarea:focus { outline:2px solid #3f5bd955; border-color:var(--azul2); }
  textarea { resize:vertical; min-height:60px; }
  .row { display:flex; gap:14px; flex-wrap:wrap; }
  .row > div { flex:1; min-width:150px; }
  .box { background:#f6f8fc; border:1px solid #e3e9f2; border-radius:10px; padding:12px 14px; margin-top:6px; }
  .chks { display:flex; gap:22px; flex-wrap:wrap; }
  .chk { display:flex; align-items:center; gap:8px; font-weight:500; cursor:pointer; }
  .chk input { width:18px; height:18px; accent-color:var(--azul2); }
  .hint { font-size:12.5px; color:#5b6b7b; margin-top:5px; }
  .carpeta-row { display:flex; gap:8px; }
  .carpeta-row input { flex:1; }
  button { background:var(--azul2); color:#fff; border:0; border-radius:9px; padding:12px 18px;
    font-size:15px; font-weight:600; cursor:pointer; }
  button:hover { filter:brightness(1.07); }
  button.sec { background:#e6ebf1; color:#1c2733; }
  button.sec:hover { background:#d5dde6; }
  button:disabled { opacity:.5; cursor:not-allowed; }
  #btn { width:100%; background:linear-gradient(90deg,#1a7f37,#22a24a); font-size:16px; padding:14px; }
  #barra-wrap { height:14px; background:#e6ebf1; border-radius:7px; overflow:hidden; margin:12px 0; display:none; }
  #barra { height:100%; width:0; background:linear-gradient(90deg,#1a7f37,#22a24a); transition:width .3s; }
  #log { font-family:'Consolas',monospace; font-size:13px; background:#0f1b2a; color:#d7e3f0;
    border-radius:9px; padding:12px; height:230px; overflow:auto; white-space:pre-wrap; display:none; }
  .ev-ok { color:#7ee2a8; } .ev-err { color:#ff9aa2; } .ev-info { color:#9ec7ff; }
  .resumen { display:none; padding:14px; border-radius:9px; background:var(--okbg); border:1px solid #a6dfba; margin-top:12px; }
</style></head>
<body>
<header>
  <div class="hwrap">
    <div class="badge">__LOGO_H__</div>
    <div>
      <h1>AOL Consultoría</h1>
      <div class="sub">Contable · Tributaria · Financiera</div>
      <div class="loc">Manizales · Colombia — Procesador Xml - Pdf y Excel (facturas DIAN)</div>
    </div>
  </div>
</header>
<div class="banner"><div class="tok">🔐 Pega tu token de la DIAN y elige qué descargar. Todo queda en tu computador.</div>
  <div id="update-banner" style="display:none;margin-top:10px;background:#fff4d6;border:1px solid #e6c200;color:#7a5c00;border-radius:10px;padding:11px 16px;font-size:14px"></div></div>
<div class="wrap">
  <div class="card">
    <h2>Buscar documentos</h2>
    <label>Cliente / empresa</label>
    <input type="text" id="cliente" list="lista-clientes" placeholder="Ej: AOL Consultoría Contable, Tributaria y Financiera" autocomplete="off">
    <datalist id="lista-clientes"></datalist>
    <div class="hint">Sirve para organizar y titular el consolidado. Al elegir uno guardado, se recuerda su carpeta.</div>

    <label>URL del token (del correo de la DIAN)</label>
    <textarea id="token" placeholder="https://catalogo-vpfe.dian.gov.co/User/AuthToken?pk=...&token=..."></textarea>
    <div class="hint">Pide el acceso por token a tu correo y pega aquí el enlace completo. El token expira; si falla, pide otro.</div>

    <label>¿Cómo buscar?</label>
    <div class="box chks">
      <label class="chk"><input type="radio" name="modo" id="modo_fechas" value="fechas" checked onchange="toggleModo()"> 📅 Por fechas</label>
      <label class="chk"><input type="radio" name="modo" id="modo_cufe" value="cufe" onchange="toggleModo()"> 🔎 Por CUFE (documentos específicos)</label>
    </div>

    <div id="bloque-fechas">
      <div class="row">
        <div><label>Desde</label><input type="date" id="desde" value="__DESDE__"></div>
        <div><label>Hasta</label><input type="date" id="hasta" value="__HASTA__"></div>
      </div>
      <div class="hint">El portal filtra por fecha de recepción del documento.</div>

      <label>¿Qué documentos? (marca los tipos por bandeja)</label>
      <div class="box">
        <div style="font-weight:600;margin-bottom:6px">📥 Compras (recibidos)</div>
        <div class="chks">
          <label class="chk"><input type="checkbox" class="tc" data-b="recibidos" value="factura" checked> Facturas</label>
          <label class="chk"><input type="checkbox" class="tc" data-b="recibidos" value="equivalente" checked> Equivalentes (POS/transporte)</label>
          <label class="chk"><input type="checkbox" class="tc" data-b="recibidos" value="soporte" checked> Doc. soporte</label>
          <label class="chk"><input type="checkbox" class="tc" data-b="recibidos" value="nota" checked> Notas</label>
        </div>
      </div>
      <div class="box" style="margin-top:8px">
        <div style="font-weight:600;margin-bottom:6px">📤 Ventas (enviados)</div>
        <div class="chks">
          <label class="chk"><input type="checkbox" class="tc" data-b="enviados" value="factura" checked> Facturas de venta</label>
          <label class="chk"><input type="checkbox" class="tc" data-b="enviados" value="nota" checked> Notas crédito</label>
          <label class="chk"><input type="checkbox" class="tc" data-b="enviados" value="nomina" checked> Nómina</label>
          <label class="chk"><input type="checkbox" class="tc" data-b="enviados" value="soporte" checked> Doc. soporte</label>
        </div>
      </div>
      <div class="hint">Una bandeja sin ningún tipo marcado no se descarga.</div>
    </div>

    <div id="bloque-cufe" style="display:none">
      <label>CUFE / CUDE (uno por línea)</label>
      <textarea id="cufes" placeholder="Pega aquí uno o varios CUFE, uno por línea…" style="min-height:100px"></textarea>
      <div class="hint">Busca esos documentos específicos en Compras y Ventas y los descarga (ignora fechas y tipos).</div>
    </div>

    <label>¿Qué guardar?</label>
    <div class="box chks">
      <label class="chk"><input type="checkbox" id="pdf"> 📄 PDF</label>
      <label class="chk"><input type="checkbox" id="xml"> 🧾 XML</label>
      <label class="chk"><input type="checkbox" id="excelcompleto" checked> 🧮 Impuestos completos en el Excel</label>
    </div>
    <div class="hint">💡 El Excel (con impuestos discriminados, concepto, vencimiento y nómina por rubros) lee el XML de cada documento — por eso tarda un poco. Marca <b>PDF/XML</b> si además quieres guardar los archivos.</div>

    <label>Velocidad</label>
    <div class="box">
      <select id="paralelo" style="width:100%;padding:11px 12px;border:1px solid #d5dbe6;border-radius:10px;font-family:inherit;font-size:14px;background:#fff;color:#22314f">
        <option value="1" selected>🐢 Normal · 1 a la vez (recomendado)</option>
        <option value="3">⚡ Turbo · 3 pestañas (experimento)</option>
        <option value="5">🚀 Turbo · 5 pestañas (experimento)</option>
      </select>
      <div class="hint">⚠️ <b>Ojo con el Turbo:</b> abre varias pestañas, pero la DIAN suele atender <b>una descarga por sesión a la vez</b>, así que puede que <b>no acelere</b> (y a veces te saca). Para saberlo: corre el mismo rango en <b>Normal</b> y en <b>Turbo</b> y compara el «<b>s/doc</b>» que aparece al final. Si el turbo falla, la app sigue sola en Normal — no pierdes nada.</div>
    </div>

    <label>Carpeta destino</label>
    <div class="carpeta-row">
      <input type="text" id="carpeta" placeholder="Ej: C:\\Users\\tu-usuario\\Documents\\Facturas DIAN">
      <button class="sec" type="button" onclick="elegirCarpeta()">Examinar…</button>
    </div>

    <div style="margin-top:20px">
      <button id="btn" onclick="iniciar()">⬇ Descargar</button>
    </div>
    <div id="barra-wrap"><div id="barra"></div></div>
    <div id="eta" style="display:none;font-size:13px;color:#3a4a63;font-weight:600;margin:2px 0 8px"></div>
    <div id="log"></div>
    <div class="resumen" id="resumen"></div>
  </div>

  <footer class="brand">
    <div class="mini">__LOGO_F__</div>
    <div class="lema">«Cada número cuenta una historia; nuestro trabajo es contarla con claridad y cuidado.»</div>
    <div class="cred">
      © 2026 AOL Consultoría Contable, Tributaria y Financiera.<br>
      Uso libre conservando los créditos. Prohibida su venta o modificación sin autorización.<br>
      Contacto: <a href="mailto:aocampol@aolcontable.com">aocampol@aolcontable.com</a><br>
      <span style="opacity:.8">Versión __VERSION__</span>
    </div>
  </footer>
</div>
<script>
async function cargarClientes(){
  const r = await fetch('/clientes'); const d = await r.json();
  const dl = document.getElementById('lista-clientes'); dl.innerHTML='';
  window._clientes = d.clientes || [];
  window._clientes.forEach(c => { const o=document.createElement('option'); o.value=c.nombre; dl.appendChild(o); });
}
document.getElementById('cliente').addEventListener('change', e=>{
  const c = (window._clientes||[]).find(x=>x.nombre===e.target.value);
  if(c && c.carpeta) document.getElementById('carpeta').value = c.carpeta;
});
async function elegirCarpeta(){
  const r = await fetch('/elegir-carpeta'); const d = await r.json();
  if(d.path) document.getElementById('carpeta').value = d.path;
  else if(d.error) alert('No se pudo abrir el diálogo. Escribe la ruta a mano.\\n'+d.error);
}
function val(id){ return document.getElementById(id).value.trim(); }
function chk(id){ return document.getElementById(id).checked; }

function toggleModo(){
  const cufe = document.getElementById('modo_cufe').checked;
  document.getElementById('bloque-fechas').style.display = cufe ? 'none' : 'block';
  document.getElementById('bloque-cufe').style.display = cufe ? 'block' : 'none';
}
function tiposPorBandeja(){
  const t = {recibidos:[], enviados:[]};
  document.querySelectorAll('.tc').forEach(c=>{ if(c.checked) t[c.dataset.b].push(c.value); });
  return t;
}
async function iniciar(){
  const modo = document.getElementById('modo_cufe').checked ? 'cufe' : 'fechas';
  const formatos = []; if(chk('pdf')) formatos.push('pdf'); if(chk('xml')) formatos.push('xml');
  const excelCompleto = chk('excelcompleto');
  if(!excelCompleto && formatos.length===0){ alert('Elige al menos qué guardar: PDF, XML o "Impuestos completos en el Excel".'); return; }
  const tipos = tiposPorBandeja();
  let cufes = [];
  if(modo==='cufe'){
    cufes = val('cufes').split(/[\\s,;]+/).map(s=>s.trim()).filter(Boolean);
    if(cufes.length===0){ alert('Pega al menos un CUFE.'); return; }
  } else {
    if(tipos.recibidos.length===0 && tipos.enviados.length===0){ alert('Marca al menos un tipo de documento (en Compras o Ventas).'); return; }
  }
  const cfg = {
    cliente: val('cliente'), token_url: val('token'), modo,
    fecha_desde: val('desde'), fecha_hasta: val('hasta'),
    cufes, tipos, formatos, excel_completo: excelCompleto,
    generar_excel: true, carpeta: val('carpeta'),
    paralelo: parseInt(document.getElementById('paralelo').value, 10) || 1
  };
  const r = await fetch('/iniciar', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(cfg)});
  if(!r.ok){ const e=await r.json(); alert(e.error||'Error'); return; }
  document.getElementById('btn').disabled = true;
  document.getElementById('log').style.display='block';
  document.getElementById('barra-wrap').style.display='block';
  document.getElementById('resumen').style.display='none';
  document.getElementById('log').innerHTML='';
  sondear();
}
function claseEv(t){ return t==='doc'?'ev-ok':t==='error'?'ev-err':'ev-info'; }
async function sondear(){
  const r = await fetch('/estado'); const d = await r.json();
  const log = document.getElementById('log');
  log.innerHTML = d.eventos.map(e=>`<div class="${claseEv(e.tipo)}">${e.msg||''}</div>`).join('');
  log.scrollTop = log.scrollHeight;
  const docs = d.eventos.filter(e=>e.tipo==='doc');
  const ult = docs[docs.length-1];
  if(ult && ult.n){ document.getElementById('barra').style.width = Math.round(100*ult.i/ult.n)+'%'; }
  if(ult && ult.eta_txt){
    const e = document.getElementById('eta');
    e.style.display='block';
    e.textContent = 'Descargado ' + ult.eta_txt + (ult.transcurrido_txt ? ' · transcurrido ' + ult.transcurrido_txt : '');
  }
  if(d.fin){
    document.getElementById('barra').style.width='100%';
    document.getElementById('btn').disabled=false;
    const res = document.getElementById('resumen');
    res.style.display='block';
    res.innerHTML = `<b>¡Listo!</b> ${d.fin.ok||0} documento(s) descargado(s).` +
      ((d.fin.no_desc>0)?` <span style="color:#b0402a">${d.fin.no_desc} no se pudieron bajar (ver hoja «No descargados»).</span>`:'') +
      (d.fin.carpeta?` <button class="sec" onclick="fetch('/abrir-carpeta?path='+encodeURIComponent('${d.fin.carpeta.replace(/\\\\/g,'\\\\\\\\')}'))">Abrir carpeta</button>`:'');
    return;
  }
  setTimeout(sondear, 1200);
}
async function checkUpdate(){
  try {
    const r = await fetch('/appinfo'); const d = await r.json();
    if(d.runtime_update){
      const b = document.getElementById('update-banner');
      b.style.display='block';
      b.innerHTML = '🔔 Hay una versión nueva de la app. ' +
        (d.full_zip ? '<a href="'+d.full_zip+'" target="_blank">Descárgala aquí</a>.'
                    : 'Pídele el nuevo instalador a AOL.') +
        (d.notas ? ' <span style="opacity:.85">('+d.notas+')</span>' : '');
    }
  } catch(e){}
}
cargarClientes();
checkUpdate();
</script>
</body></html>""".replace("__DESDE__", _primero).replace("__HASTA__", _hoy) \
    .replace("__LOGO_H__", _LOGO_H).replace("__LOGO_F__", _LOGO_F).replace("__FAVICON__", _FAV) \
    .replace("__VERSION__", str(APP_VERSION))


def main():
    url = f"http://127.0.0.1:{PUERTO}"
    print(f"→ Abriendo {url}")
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    uvicorn.run(app, host="127.0.0.1", port=PUERTO, log_level="warning")


if __name__ == "__main__":
    main()
