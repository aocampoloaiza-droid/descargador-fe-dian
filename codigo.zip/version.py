"""Versión de la app. CODE_VERSION se auto-actualiza por internet; RUNTIME_VERSION
solo cambia cuando hay que re-descargar el paquete completo (navegador, etc.)."""
CODE_VERSION = 18       # sube con cada cambio de código (se actualiza solo)
RUNTIME_VERSION = 1     # sube solo en updates grandes (re-descarga completa)
NOMBRE = "Procesador Xml - Pdf y Excel"
